# Graphical Calculator
<hr>
<h3>Created by:</h3>
<ul>
<li>Oleksandr Lisnytskyi</li>
<li>Kenny Joseph</li>
<li>Vadim Rudenko</li>
</ul>